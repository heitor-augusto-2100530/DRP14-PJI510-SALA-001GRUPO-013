import React from 'react';
import { useNavigate } from 'react-router-dom';
import { usePantry } from '@/context/PantryContext';
import { UnitType } from '@/types/pantry';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

const units: UnitType[] = [
  'kg', 'g', 'l', 'ml', 'oz', 'lb', 'pcs', 
  'pack', 'box', 'can', 'bottle', 'jar'
];

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  quantity: z.coerce.number().positive({ message: "Quantity must be positive" }),
  unit: z.string(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const AddShoppingItemPage: React.FC = () => {
  const { addToShoppingList } = usePantry();
  const navigate = useNavigate();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      quantity: 1,
      unit: 'pcs',
      notes: '',
    },
  });
  
  const onSubmit = (data: FormValues) => {
    // Make sure all required fields are passed as non-optional
    addToShoppingList({
      name: data.name,
      quantity: data.quantity,
      unit: data.unit,
      notes: data.notes,
      isPurchased: false,
    });
    
    navigate('/shopping-list');
  };
  
  return (
    <div className="container mx-auto max-w-xl p-4 bg-white shadow-sm rounded-lg animate-fade-in">
      <h2 className="text-2xl font-poppins font-bold text-forest mb-6">Adicionar Item à Lista de Compras</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome do Item</FormLabel>
                <FormControl>
                  <Input placeholder="Digite o nome do item" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantidade</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="0" 
                      step="0.01"
                      {...field} 
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="unit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Unidade</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione unidade" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Observações</FormLabel>
                <FormControl>
                  <Textarea placeholder="Adicione observações (opcional)" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-end gap-4">
            <Button 
              type="button" 
              variant="outline"
              onClick={() => navigate('/shopping-list')}
            >
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-forest hover:bg-forest/90 text-white"
            >
              Adicionar à Lista
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default AddShoppingItemPage;

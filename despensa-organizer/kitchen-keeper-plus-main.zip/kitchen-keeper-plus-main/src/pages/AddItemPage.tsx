import React from 'react';
import { useNavigate } from 'react-router-dom';
import { usePantry } from '@/context/PantryContext';
import { PantryCategory, UnitType } from '@/types/pantry';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const categories: PantryCategory[] = [
  'dairy', 'produce', 'meat', 'frozen', 'canned', 
  'dry', 'beverages', 'spices', 'bakery', 'snacks', 'other'
];

const units: UnitType[] = [
  'kg', 'g', 'l', 'ml', 'oz', 'lb', 'pcs', 
  'pack', 'box', 'can', 'bottle', 'jar'
];

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  category: z.string(),
  quantity: z.coerce.number().positive({ message: "Quantity must be positive" }),
  unit: z.string(),
  expirationDate: z.date().nullable(),
  status: z.enum(['open', 'closed', 'half-finished', 'finished']),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const AddItemPage: React.FC = () => {
  const { addPantryItem } = usePantry();
  const navigate = useNavigate();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      category: 'other',
      quantity: 1,
      unit: 'pcs',
      expirationDate: null,
      status: 'closed',
      notes: '',
    },
  });
  
  const onSubmit = (data: FormValues) => {
    addPantryItem({
      name: data.name,
      category: data.category,
      quantity: data.quantity,
      unit: data.unit,
      status: data.status,
      notes: data.notes,
      purchaseDate: new Date().toISOString(),
      expirationDate: data.expirationDate ? data.expirationDate.toISOString() : null,
    });
    
    navigate('/');
  };
  
  return (
    <div className="container mx-auto max-w-xl p-4 bg-white shadow-sm rounded-lg animate-fade-in">
      <h2 className="text-2xl font-poppins font-bold text-forest mb-6">Adicionar Novo Item</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome do Item</FormLabel>
                <FormControl>
                  <Input placeholder="Digite o nome do item" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Categoria</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category === 'dairy' && 'Laticínios'}
                          {category === 'produce' && 'Hortifruti'}
                          {category === 'meat' && 'Carnes'}
                          {category === 'frozen' && 'Congelados'}
                          {category === 'canned' && 'Enlatados'}
                          {category === 'dry' && 'Secos'}
                          {category === 'beverages' && 'Bebidas'}
                          {category === 'spices' && 'Temperos'}
                          {category === 'bakery' && 'Padaria'}
                          {category === 'snacks' && 'Lanches'}
                          {category === 'other' && 'Outros'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="closed">Fechado</SelectItem>
                      <SelectItem value="open">Aberto</SelectItem>
                      <SelectItem value="half-finished">Pela Metade</SelectItem>
                      <SelectItem value="finished">Terminado</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantidade</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="0"
                      step="0.01" 
                      {...field} 
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="unit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Unidade</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a unidade" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="expirationDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Data de Validade</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={`w-full pl-3 text-left font-normal ${!field.value ? "text-muted-foreground" : ""}`}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Escolha uma data</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value || undefined}
                      onSelect={field.onChange}
                      disabled={(date) =>
                        date < new Date(new Date().setHours(0, 0, 0, 0))
                      }
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormDescription>
                  Opcional - quando este item irá vencer?
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Observações</FormLabel>
                <FormControl>
                  <Textarea placeholder="Adicione observações (opcional)" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-end gap-4">
            <Button 
              type="button" 
              variant="outline"
              onClick={() => navigate('/')}
            >
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-forest hover:bg-forest/90 text-white"
            >
              Adicionar Item
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default AddItemPage;

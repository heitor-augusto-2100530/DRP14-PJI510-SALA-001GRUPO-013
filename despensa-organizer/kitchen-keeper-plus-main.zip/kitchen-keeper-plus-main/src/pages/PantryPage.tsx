import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { usePantry } from '@/context/PantryContext';
import { PantryCategory, PantryItem } from '@/types/pantry';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus } from 'lucide-react';
import PantryItemCard from '@/components/PantryItemCard';

const categories: PantryCategory[] = [
  'dairy', 'produce', 'meat', 'frozen', 'canned', 
  'dry', 'beverages', 'spices', 'bakery', 'snacks', 'other'
];

const PantryPage: React.FC = () => {
  const { pantryItems } = usePantry();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const filteredItems = pantryItems.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const openItems = filteredItems.filter(item => item.status === 'open');
  const halfFinishedItems = filteredItems.filter(item => item.status === 'half-finished');
  const closedItems = filteredItems.filter(item => item.status === 'closed');
  const finishedItems = filteredItems.filter(item => item.status === 'finished');
  
  return (
    <div className="container mx-auto animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div className="flex-1 w-full sm:w-auto">
          <Input
            placeholder="Pesquisar itens..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
        </div>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas Categorias</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category === 'dairy' && 'Laticínios'}
                  {category === 'produce' && 'Hortifruti'}
                  {category === 'meat' && 'Carnes'}
                  {category === 'frozen' && 'Congelados'}
                  {category === 'canned' && 'Enlatados'}
                  {category === 'dry' && 'Secos'}
                  {category === 'beverages' && 'Bebidas'}
                  {category === 'spices' && 'Temperos'}
                  {category === 'bakery' && 'Padaria'}
                  {category === 'snacks' && 'Lanches'}
                  {category === 'other' && 'Outros'}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button asChild size="sm" className="bg-forest hover:bg-forest/90 text-white font-poppins">
            <Link to="/add-item">
              <Plus className="h-4 w-4 mr-1" />
              Adicionar Item
            </Link>
          </Button>
        </div>
      </div>
      
      {filteredItems.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="text-xl font-poppins font-bold mb-2">Nenhum item encontrado</h3>
          <p className="text-muted-foreground mb-6">Comece adicionando itens à sua despensa</p>
          <Button asChild className="bg-forest hover:bg-forest/90 font-poppins">
            <Link to="/add-item">
              <Plus className="h-5 w-5 mr-2" />
              Adicionar Primeiro Item
            </Link>
          </Button>
        </div>
      ) : (
        <div className="space-y-8">
          {openItems.length > 0 && (
            <section>
              <h2 className="text-lg font-poppins font-bold mb-3 text-forest">Itens Abertos</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {openItems.map((item) => (
                  <PantryItemCard key={item.id} item={item} />
                ))}
              </div>
            </section>
          )}
          
          {halfFinishedItems.length > 0 && (
            <section>
              <h2 className="text-lg font-poppins font-bold mb-3 text-sage">Itens Pela Metade</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {halfFinishedItems.map((item) => (
                  <PantryItemCard key={item.id} item={item} />
                ))}
              </div>
            </section>
          )}
          
          {closedItems.length > 0 && (
            <section>
              <h2 className="text-lg font-poppins font-bold mb-3 text-slate">Itens Fechados</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {closedItems.map((item) => (
                  <PantryItemCard key={item.id} item={item} />
                ))}
              </div>
            </section>
          )}
          
          {finishedItems.length > 0 && (
            <section>
              <h2 className="text-lg font-poppins font-bold mb-3 text-muted-foreground">Itens Terminados</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {finishedItems.map((item) => (
                  <PantryItemCard key={item.id} item={item} />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
};

export default PantryPage;

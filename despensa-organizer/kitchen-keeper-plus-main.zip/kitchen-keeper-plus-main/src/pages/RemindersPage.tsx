
import React, { useEffect, useState } from 'react';
import { usePantry } from '@/context/PantryContext';
import { addDays, format, isBefore, parseISO } from 'date-fns';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlarmClock, Calendar, ShoppingCart } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

const RemindersPage: React.FC = () => {
  const { pantryItems, transferToShoppingList } = usePantry();
  const [expiringItems, setExpiringItems] = useState<Array<{ item: typeof pantryItems[0], daysLeft: number }>>([]);
  const [lastPurchaseItems, setLastPurchaseItems] = useState<Array<{ item: typeof pantryItems[0], daysSince: number }>>([]);
  
  useEffect(() => {
    const today = new Date();
    const expiringList: Array<{ item: typeof pantryItems[0], daysLeft: number }> = [];
    const purchaseList: Array<{ item: typeof pantryItems[0], daysSince: number }> = [];
    
    pantryItems.forEach(item => {
      // Check for expiring items
      if (item.expirationDate) {
        const expDate = parseISO(item.expirationDate);
        const fourteenDaysFromNow = addDays(today, 14);
        
        if (isBefore(expDate, fourteenDaysFromNow) && !isBefore(expDate, today)) {
          const daysLeft = Math.ceil((expDate.getTime() - today.getTime()) / (1000 * 3600 * 24));
          expiringList.push({ item, daysLeft });
        }
      }
      
      // Check for items not purchased in a while
      const purchaseDate = parseISO(item.purchaseDate);
      const thirtyDaysAgo = addDays(today, -30);
      
      if (isBefore(purchaseDate, thirtyDaysAgo) && (item.status === 'finished' || item.quantity <= 0)) {
        const daysSince = Math.ceil((today.getTime() - purchaseDate.getTime()) / (1000 * 3600 * 24));
        purchaseList.push({ item, daysSince });
      }
    });
    
    // Sort expiring items by days left
    expiringList.sort((a, b) => a.daysLeft - b.daysLeft);
    
    // Sort last purchase items by days since purchase (descending)
    purchaseList.sort((a, b) => b.daysSince - a.daysSince);
    
    setExpiringItems(expiringList);
    setLastPurchaseItems(purchaseList);
  }, [pantryItems]);
  
  return (
    <div className="container mx-auto animate-fade-in">
      <Tabs defaultValue="expiring">
        <TabsList className="mb-6 w-full">
          <TabsTrigger value="expiring" className="w-1/2">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>Expiring Items</span>
              {expiringItems.length > 0 && (
                <Badge variant="destructive" className="ml-1">
                  {expiringItems.length}
                </Badge>
              )}
            </div>
          </TabsTrigger>
          <TabsTrigger value="purchase" className="w-1/2">
            <div className="flex items-center gap-2">
              <AlarmClock className="h-4 w-4" />
              <span>Purchase Reminders</span>
              {lastPurchaseItems.length > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {lastPurchaseItems.length}
                </Badge>
              )}
            </div>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="expiring">
          <Card>
            <CardHeader className="bg-muted/30">
              <CardTitle className="text-forest font-poppins text-lg">
                Items Expiring Soon
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              {expiringItems.length === 0 ? (
                <div className="text-center py-12">
                  <Calendar className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-bold mb-2">No items expiring soon</h3>
                  <p className="text-muted-foreground">All your items are still fresh</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {expiringItems.map(({ item, daysLeft }) => (
                    <div key={item.id} className="border-b pb-4 mb-4 last:border-0 last:mb-0 last:pb-0">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-poppins font-medium text-lg">{item.name}</h3>
                          <p className="text-sm font-roboto text-muted-foreground">
                            {item.quantity} {item.unit} • {item.category}
                          </p>
                        </div>
                        <Badge className={
                          daysLeft <= 3 
                            ? "bg-destructive text-destructive-foreground" 
                            : daysLeft <= 7 
                            ? "bg-orange-500 text-white" 
                            : "bg-yellow-500"
                        }>
                          {daysLeft === 1 ? "Tomorrow" : `${daysLeft} days left`}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center mt-3">
                        <p className="text-sm font-roboto">
                          Expires: {format(parseISO(item.expirationDate!), 'MMM d, yyyy')}
                        </p>
                        <Button 
                          variant="outline" 
                          className="border-forest text-forest hover:bg-forest/10" 
                          size="sm"
                          onClick={() => transferToShoppingList(item.id)}
                        >
                          <ShoppingCart className="h-4 w-4 mr-1" /> Add to Shopping List
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="purchase">
          <Card>
            <CardHeader className="bg-muted/30">
              <CardTitle className="text-forest font-poppins text-lg">
                Items You Haven't Purchased Recently
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              {lastPurchaseItems.length === 0 ? (
                <div className="text-center py-12">
                  <AlarmClock className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-bold mb-2">No purchase reminders</h3>
                  <p className="text-muted-foreground">You've been keeping your pantry stocked</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {lastPurchaseItems.map(({ item, daysSince }) => (
                    <div key={item.id} className="border-b pb-4 mb-4 last:border-0 last:mb-0 last:pb-0">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-poppins font-medium text-lg">{item.name}</h3>
                          <p className="text-sm font-roboto text-muted-foreground">
                            {item.category} • Status: {item.status}
                          </p>
                        </div>
                        <Badge variant="outline" className="bg-slate text-white">
                          {formatDistanceToNow(parseISO(item.purchaseDate))} ago
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center mt-3">
                        <p className="text-sm font-roboto">
                          Last purchased: {format(parseISO(item.purchaseDate), 'MMM d, yyyy')}
                        </p>
                        <Button 
                          variant="outline" 
                          className="border-forest text-forest hover:bg-forest/10" 
                          size="sm"
                          onClick={() => transferToShoppingList(item.id)}
                        >
                          <ShoppingCart className="h-4 w-4 mr-1" /> Add to Shopping List
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RemindersPage;

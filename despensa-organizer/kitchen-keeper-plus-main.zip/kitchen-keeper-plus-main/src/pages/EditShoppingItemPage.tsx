
import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { usePantry } from '@/context/PantryContext';
import { UnitType } from '@/types/pantry';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

const units: UnitType[] = [
  'kg', 'g', 'l', 'ml', 'oz', 'lb', 'pcs', 
  'pack', 'box', 'can', 'bottle', 'jar'
];

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  quantity: z.coerce.number().positive({ message: "Quantity must be positive" }),
  unit: z.string(),
  isPurchased: z.boolean(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const EditShoppingItemPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { shoppingList, updateShoppingListItem } = usePantry();
  const navigate = useNavigate();
  
  const shoppingItem = shoppingList.find(item => item.id === id);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      quantity: 1,
      unit: 'pcs',
      isPurchased: false,
      notes: '',
    },
  });
  
  useEffect(() => {
    if (shoppingItem) {
      form.reset({
        name: shoppingItem.name,
        quantity: shoppingItem.quantity,
        unit: shoppingItem.unit,
        isPurchased: shoppingItem.isPurchased,
        notes: shoppingItem.notes || '',
      });
    } else {
      navigate('/shopping-list');
    }
  }, [shoppingItem, form, navigate]);
  
  const onSubmit = (data: FormValues) => {
    if (id) {
      updateShoppingListItem(id, data);
      navigate('/shopping-list');
    }
  };
  
  if (!shoppingItem) {
    return null;
  }
  
  return (
    <div className="container mx-auto max-w-xl p-4 bg-white shadow-sm rounded-lg animate-fade-in">
      <h2 className="text-2xl font-poppins font-bold text-forest mb-6">Edit Shopping List Item</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Item Name</FormLabel>
                <FormControl>
                  <Input placeholder="Enter item name" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="0" 
                      step="0.01"
                      {...field} 
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="unit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Unit</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select unit" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl>
                  <Textarea placeholder="Add any additional notes (optional)" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              className="border-red-500 text-red-500 hover:bg-red-50"
              onClick={() => navigate('/shopping-list')}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-forest hover:bg-forest/90 text-white"
            >
              Update Item
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default EditShoppingItemPage;

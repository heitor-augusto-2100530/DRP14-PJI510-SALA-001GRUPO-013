
import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { usePantry } from '@/context/PantryContext';
import { PantryCategory, UnitType } from '@/types/pantry';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const categories: PantryCategory[] = [
  'dairy', 'produce', 'meat', 'frozen', 'canned', 
  'dry', 'beverages', 'spices', 'bakery', 'snacks', 'other'
];

const units: UnitType[] = [
  'kg', 'g', 'l', 'ml', 'oz', 'lb', 'pcs', 
  'pack', 'box', 'can', 'bottle', 'jar'
];

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  category: z.string(),
  quantity: z.coerce.number().positive({ message: "Quantity must be positive" }),
  unit: z.string(),
  expirationDate: z.date().nullable(),
  status: z.enum(['open', 'closed', 'half-finished', 'finished']),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const EditItemPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { pantryItems, updatePantryItem } = usePantry();
  const navigate = useNavigate();
  
  const pantryItem = pantryItems.find(item => item.id === id);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      category: 'other',
      quantity: 1,
      unit: 'pcs',
      expirationDate: null,
      status: 'closed',
      notes: '',
    },
  });
  
  useEffect(() => {
    if (pantryItem) {
      form.reset({
        name: pantryItem.name,
        category: pantryItem.category,
        quantity: pantryItem.quantity,
        unit: pantryItem.unit,
        expirationDate: pantryItem.expirationDate ? parseISO(pantryItem.expirationDate) : null,
        status: pantryItem.status,
        notes: pantryItem.notes || '',
      });
    } else {
      navigate('/');
    }
  }, [pantryItem, form, navigate]);
  
  const onSubmit = (data: FormValues) => {
    if (id) {
      updatePantryItem(id, {
        ...data,
        expirationDate: data.expirationDate ? data.expirationDate.toISOString() : null,
      });
      
      navigate('/');
    }
  };
  
  if (!pantryItem) {
    return null; // We'll navigate away in the useEffect, but this prevents rendering errors
  }
  
  return (
    <div className="container mx-auto max-w-xl p-4 bg-white shadow-sm rounded-lg animate-fade-in">
      <h2 className="text-2xl font-poppins font-bold text-forest mb-6">Edit Pantry Item</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Item Name</FormLabel>
                <FormControl>
                  <Input placeholder="Enter item name" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="closed">Closed</SelectItem>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="half-finished">Half-Finished</SelectItem>
                      <SelectItem value="finished">Finished</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="0" 
                      step="0.01"
                      {...field} 
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="unit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Unit</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select unit" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="expirationDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Expiration Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={`w-full pl-3 text-left font-normal ${!field.value ? "text-muted-foreground" : ""}`}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value || undefined}
                      onSelect={field.onChange}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormDescription>
                  Optional - when will this item expire?
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl>
                  <Textarea placeholder="Add any additional notes (optional)" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              className="border-red-500 text-red-500 hover:bg-red-50"
              onClick={() => navigate('/')}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-forest hover:bg-forest/90 text-white"
            >
              Update Item
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default EditItemPage;

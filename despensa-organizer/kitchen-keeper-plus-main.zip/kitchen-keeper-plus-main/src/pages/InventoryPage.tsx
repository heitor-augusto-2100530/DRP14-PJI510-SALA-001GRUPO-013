import React, { useState } from 'react';
import { usePantry } from '@/context/PantryContext';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PantryCategory } from '@/types/pantry';
import StatusBadge from '@/components/StatusBadge';
import ExpirationBadge from '@/components/ExpirationBadge';
import { Button } from '@/components/ui/button';
import { Edit, ShoppingCart, Trash2 } from 'lucide-react';
import { Table, TableHeader, TableBody, TableFooter, TableHead, TableRow, TableCell } from '@/components/ui/table';
import { formatDistanceToNow, parseISO } from 'date-fns';
import { useNavigate } from 'react-router-dom';

const categories: PantryCategory[] = [
  'dairy', 'produce', 'meat', 'frozen', 'canned', 
  'dry', 'beverages', 'spices', 'bakery', 'snacks', 'other'
];

const InventoryPage: React.FC = () => {
  const { pantryItems, deletePantryItem, transferToShoppingList } = usePantry();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const navigate = useNavigate();

  const filteredItems = pantryItems.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    return matchesSearch && matchesCategory && matchesStatus;
  });
  
  const sortedItems = [...filteredItems].sort((a, b) => a.name.localeCompare(b.name));
  
  return (
    <div className="container mx-auto animate-fade-in">
      <div className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4 mb-6">
        <Input
          placeholder="Pesquisar inventário..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="md:w-1/3"
        />
        
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="md:w-1/4">
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas Categorias</SelectItem>
            {categories.map((category) => (
              <SelectItem key={category} value={category}>
                {category === 'dairy' && 'Laticínios'}
                {category === 'produce' && 'Hortifruti'}
                {category === 'meat' && 'Carnes'}
                {category === 'frozen' && 'Congelados'}
                {category === 'canned' && 'Enlatados'}
                {category === 'dry' && 'Secos'}
                {category === 'beverages' && 'Bebidas'}
                {category === 'spices' && 'Temperos'}
                {category === 'bakery' && 'Padaria'}
                {category === 'snacks' && 'Lanches'}
                {category === 'other' && 'Outros'}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="md:w-1/4">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos Status</SelectItem>
            <SelectItem value="open">Aberto</SelectItem>
            <SelectItem value="closed">Fechado</SelectItem>
            <SelectItem value="half-finished">Pela Metade</SelectItem>
            <SelectItem value="finished">Terminado</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {sortedItems.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Nenhum item encontrado</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <Table className="border rounded-md">
            <TableHeader className="bg-muted/30">
              <TableRow>
                <TableHead className="font-poppins">Item</TableHead>
                <TableHead className="font-poppins">Categoria</TableHead>
                <TableHead className="font-poppins">Quantidade</TableHead>
                <TableHead className="font-poppins">Status</TableHead>
                <TableHead className="font-poppins">Última Compra</TableHead>
                <TableHead className="font-poppins">Validade</TableHead>
                <TableHead className="font-poppins">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedItems.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-montserrat font-medium">{item.name}</TableCell>
                  <TableCell className="font-roboto capitalize">{item.category}</TableCell>
                  <TableCell className="font-roboto">
                    {item.quantity} {item.unit}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={item.status} />
                  </TableCell>
                  <TableCell className="font-roboto text-sm">
                    {formatDistanceToNow(parseISO(item.purchaseDate))} ago
                  </TableCell>
                  <TableCell>
                    <ExpirationBadge date={item.expirationDate} />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => transferToShoppingList(item.id)}
                        title="Adicionar ao carrinho"
                      >
                        <ShoppingCart className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => navigate(`/edit-item/${item.id}`)}
                        title="Editar item"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-destructive hover:text-destructive" 
                        onClick={() => deletePantryItem(item.id)}
                        title="Excluir item"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TableCell colSpan={7} className="text-right font-poppins">
                  Total de Itens: {sortedItems.length}
                </TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </div>
      )}
    </div>
  );
};

export default InventoryPage;

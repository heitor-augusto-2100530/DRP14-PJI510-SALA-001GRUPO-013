
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { usePantry } from '@/context/PantryContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Check, ShoppingCart } from 'lucide-react';
import ShoppingListItem from '@/components/ShoppingListItem';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const ShoppingListPage: React.FC = () => {
  const { shoppingList } = usePantry();
  const [searchTerm, setSearchTerm] = useState('');

  // Filter shopping list items
  const filteredItems = shoppingList.filter((item) => {
    return item.name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // Separate purchased and non-purchased items
  const nonPurchasedItems = filteredItems.filter(item => !item.isPurchased);
  const purchasedItems = filteredItems.filter(item => item.isPurchased);
  
  return (
    <div className="container mx-auto animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div className="flex-1 w-full sm:w-auto">
          <Input
            placeholder="Search shopping list..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
        </div>
        
        <Button asChild size="sm" className="bg-forest hover:bg-forest/90 text-white font-poppins w-full sm:w-auto">
          <Link to="/add-shopping-item">
            <Plus className="h-4 w-4 mr-1" />
            Add to List
          </Link>
        </Button>
      </div>
      
      {filteredItems.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingCart className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-poppins font-bold mb-2">Your shopping list is empty</h3>
          <p className="text-muted-foreground mb-6">Add items that you need to buy</p>
          <Button asChild className="bg-forest hover:bg-forest/90 font-poppins">
            <Link to="/add-shopping-item">
              <Plus className="h-5 w-5 mr-2" />
              Add First Item
            </Link>
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          <Card className="bg-white">
            <CardHeader className="pb-3 border-b">
              <CardTitle className="text-lg font-poppins text-forest flex items-center gap-2">
                <ShoppingCart className="h-5 w-5" />
                To Buy ({nonPurchasedItems.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {nonPurchasedItems.length === 0 ? (
                <div className="py-6 text-center">
                  <Check className="h-12 w-12 mx-auto mb-2 text-forest" />
                  <p className="text-muted-foreground">All items purchased!</p>
                </div>
              ) : (
                <div>
                  {nonPurchasedItems.map((item) => (
                    <ShoppingListItem key={item.id} item={item} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
          
          {purchasedItems.length > 0 && (
            <Card className="bg-white/80">
              <CardHeader className="pb-3 border-b">
                <CardTitle className="text-lg font-poppins text-muted-foreground flex items-center gap-2">
                  <Check className="h-5 w-5" />
                  Purchased ({purchasedItems.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {purchasedItems.map((item) => (
                  <ShoppingListItem key={item.id} item={item} />
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default ShoppingListPage;


import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import PantryPage from "@/pages/PantryPage";
import ShoppingListPage from "@/pages/ShoppingListPage";
import InventoryPage from "@/pages/InventoryPage";
import RemindersPage from "@/pages/RemindersPage";
import AddItemPage from "@/pages/AddItemPage";
import EditItemPage from "@/pages/EditItemPage";
import AddShoppingItemPage from "@/pages/AddShoppingItemPage";
import EditShoppingItemPage from "@/pages/EditShoppingItemPage";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner position="top-right" expand richColors closeButton />
      <BrowserRouter>
        <Routes>
          <Route element={<AppLayout />}>
            <Route path="/" element={<PantryPage />} />
            <Route path="/shopping-list" element={<ShoppingListPage />} />
            <Route path="/inventory" element={<InventoryPage />} />
            <Route path="/reminders" element={<RemindersPage />} />
            <Route path="/add-item" element={<AddItemPage />} />
            <Route path="/edit-item/:id" element={<EditItemPage />} />
            <Route path="/add-shopping-item" element={<AddShoppingItemPage />} />
            <Route path="/edit-shopping-item/:id" element={<EditShoppingItemPage />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

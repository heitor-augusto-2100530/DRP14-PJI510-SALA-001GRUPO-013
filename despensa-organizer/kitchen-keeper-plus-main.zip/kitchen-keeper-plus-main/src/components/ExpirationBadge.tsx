
import React from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { addDays, format, isBefore, parseISO } from "date-fns";

interface ExpirationBadgeProps {
  date: string | null;
  className?: string;
}

const ExpirationBadge: React.FC<ExpirationBadgeProps> = ({ date, className }) => {
  if (!date) return null;
  
  const expDate = parseISO(date);
  const today = new Date();
  const threeDaysFromNow = addDays(today, 3);
  const sevenDaysFromNow = addDays(today, 7);
  
  let badgeColor = "";
  let label = format(expDate, 'MMM d, yyyy');
  
  if (isBefore(expDate, today)) {
    badgeColor = "bg-destructive text-destructive-foreground";
    label = `Expired: ${label}`;
  } else if (isBefore(expDate, threeDaysFromNow)) {
    badgeColor = "bg-orange-500 text-white";
    label = `Expires soon: ${label}`;
  } else if (isBefore(expDate, sevenDaysFromNow)) {
    badgeColor = "bg-yellow-500 text-foreground";
    label = `Expires: ${label}`;
  } else {
    badgeColor = "bg-muted text-muted-foreground";
    label = `Expires: ${label}`;
  }
  
  return (
    <Badge 
      className={cn(badgeColor, className)}
      variant="outline"
    >
      {label}
    </Badge>
  );
};

export default ExpirationBadge;

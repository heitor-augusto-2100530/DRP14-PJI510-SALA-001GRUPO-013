
import React from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: 'open' | 'closed' | 'half-finished' | 'finished';
  className?: string;
}

const statusConfig = {
  'open': {
    label: 'Open',
    className: 'bg-forest text-white',
  },
  'closed': {
    label: 'Closed',
    className: 'bg-slate text-white',
  },
  'half-finished': {
    label: 'Half Finished',
    className: 'bg-sage text-foreground',
  },
  'finished': {
    label: 'Finished',
    className: 'bg-muted text-muted-foreground',
  },
};

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className }) => {
  const config = statusConfig[status];
  
  return (
    <Badge 
      className={cn(config.className, className)}
      variant="outline"
    >
      {config.label}
    </Badge>
  );
};

export default StatusBadge;


import { Outlet } from "react-router-dom";
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarTrigger,
  SidebarHeader,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Home, ShoppingCart, Archive, Bell, ListChecks } from "lucide-react";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { PantryProvider } from "@/context/PantryContext";
import { useState, useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { useIsMobile } from "@/hooks/use-mobile";

export function AppLayout() {
  const location = useLocation();
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = useState(!isMobile);
  
  useEffect(() => {
    if (isMobile) {
      setIsOpen(false);
    } else {
      setIsOpen(true);
    }
  }, [isMobile]);

  // Close sidebar on mobile when navigating
  useEffect(() => {
    if (isMobile) {
      setIsOpen(false);
    }
  }, [location.pathname, isMobile]);

  return (
    <ThemeProvider defaultTheme="light" storageKey="kitchen-keeper-theme">
      <PantryProvider>
        <SidebarProvider defaultProps={{ open: !isMobile, position: isMobile ? "overlay" : "static" }}>
          <div className="min-h-screen flex w-full bg-cream">
            <Sidebar open={isOpen} onOpenChange={setIsOpen}>
              <SidebarHeader className="font-poppins">
                <div className="flex flex-col">
                  <h1 className="text-lg font-bold text-forest">Controle de Despensa</h1>
                  <p className="text-xs text-muted-foreground">Gestão de Despensa</p>
                </div>
              </SidebarHeader>
              <SidebarContent>
                <SidebarGroup>
                  <SidebarGroupLabel>Menu Principal</SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu>
                      <SidebarMenuItem>
                        <SidebarMenuButton asChild className={location.pathname === '/' ? 'bg-sidebar-primary' : ''}>
                          <Link to="/">
                            <Home />
                            <span>Despensa</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <SidebarMenuButton asChild className={location.pathname === '/shopping-list' ? 'bg-sidebar-primary' : ''}>
                          <Link to="/shopping-list">
                            <ShoppingCart />
                            <span>Lista de Compras</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <SidebarMenuButton asChild className={location.pathname === '/inventory' ? 'bg-sidebar-primary' : ''}>
                          <Link to="/inventory">
                            <Archive />
                            <span>Inventário</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <SidebarMenuButton asChild className={location.pathname === '/reminders' ? 'bg-sidebar-primary' : ''}>
                          <Link to="/reminders">
                            <Bell />
                            <span>Lembretes</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
                <SidebarGroup>
                  <SidebarGroupLabel>Atalhos</SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu>
                      <SidebarMenuItem>
                        <SidebarMenuButton asChild>
                          <Link to="/add-item">
                            <ListChecks />
                            <span>Adicionar Item</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
              </SidebarContent>
              <SidebarFooter>
                <p className="text-xs text-center text-muted-foreground py-2">
                  Controle de Despensa v1.0
                </p>
              </SidebarFooter>
            </Sidebar>

            <div className="flex-1 overflow-auto">
              <div className="flex items-center h-16 px-4 border-b bg-white/50 backdrop-blur-sm sticky top-0 z-10">
                <SidebarTrigger />
                <div className="ml-4 font-poppins">
                  {location.pathname === '/' && <h2 className="font-bold">Minha Despensa</h2>}
                  {location.pathname === '/shopping-list' && <h2 className="font-bold">Lista de Compras</h2>}
                  {location.pathname === '/inventory' && <h2 className="font-bold">Inventário</h2>}
                  {location.pathname === '/reminders' && <h2 className="font-bold">Lembretes</h2>}
                  {location.pathname === '/add-item' && <h2 className="font-bold">Adicionar Novo Item</h2>}
                  {location.pathname.startsWith('/edit-item/') && <h2 className="font-bold">Editar Item</h2>}
                  {location.pathname.startsWith('/edit-shopping-item/') && <h2 className="font-bold">Editar Item da Lista</h2>}
                </div>
              </div>
              <main className="p-4 md:p-6">
                <Outlet />
              </main>
            </div>
          </div>
        </SidebarProvider>
      </PantryProvider>
    </ThemeProvider>
  );
}

export default AppLayout;

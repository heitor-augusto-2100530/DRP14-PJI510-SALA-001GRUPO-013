
import React from 'react';
import { ShoppingListItem as ShoppingListItemType } from '@/types/pantry';
import { usePantry } from '@/context/PantryContext';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Edit, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ShoppingListItemProps {
  item: ShoppingListItemType;
}

const ShoppingListItem: React.FC<ShoppingListItemProps> = ({ item }) => {
  const { markAsPurchased, removeFromShoppingList } = usePantry();
  const navigate = useNavigate();
  
  const handlePurchasedChange = () => {
    markAsPurchased(item.id);
  };
  
  const handleEdit = () => {
    navigate(`/edit-shopping-item/${item.id}`);
  };
  
  const handleDelete = () => {
    removeFromShoppingList(item.id);
  };
  
  return (
    <div className={`flex items-center justify-between p-3 border-b transition-colors ${
      item.isPurchased ? 'bg-muted/30' : 'hover:bg-muted/10'
    }`}>
      <div className="flex items-center gap-3">
        <Checkbox 
          id={`item-${item.id}`}
          checked={item.isPurchased}
          onCheckedChange={handlePurchasedChange}
          className="h-5 w-5"
        />
        <div className="flex flex-col">
          <label 
            htmlFor={`item-${item.id}`} 
            className={`font-medium cursor-pointer ${
              item.isPurchased ? 'line-through text-muted-foreground' : ''
            }`}
          >
            {item.name}
          </label>
          <span className="text-sm text-muted-foreground">
            {item.quantity} {item.unit}
          </span>
          {item.notes && (
            <span className="text-xs text-muted-foreground mt-1">
              {item.notes}
            </span>
          )}
        </div>
      </div>
      
      <div className="flex items-center gap-1">
        <Button 
          variant="ghost" 
          size="icon"
          className="h-8 w-8" 
          onClick={handleEdit}
        >
          <Edit className="h-4 w-4" />
          <span className="sr-only">Edit</span>
        </Button>
        <Button 
          variant="ghost" 
          size="icon"
          className="h-8 w-8 text-destructive hover:text-destructive" 
          onClick={handleDelete}
        >
          <Trash2 className="h-4 w-4" />
          <span className="sr-only">Delete</span>
        </Button>
      </div>
    </div>
  );
};

export default ShoppingListItem;


import { PantryItem } from "@/types/pantry";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Calendar, Clock, Edit, MoreVertical, ShoppingCart, Trash2 } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import ExpirationBadge from "@/components/ExpirationBadge";
import { formatDistanceToNow, parseISO } from "date-fns";
import { usePantry } from "@/context/PantryContext";
import { useNavigate } from "react-router-dom";

interface PantryItemCardProps {
  item: PantryItem;
}

const PantryItemCard: React.FC<PantryItemCardProps> = ({ item }) => {
  const { deletePantryItem, transferToShoppingList } = usePantry();
  const navigate = useNavigate();
  
  const handleEdit = () => {
    navigate(`/edit-item/${item.id}`);
  };

  const handleDelete = () => {
    deletePantryItem(item.id);
  };

  const handleAddToShoppingList = () => {
    transferToShoppingList(item.id);
  };
  
  return (
    <Card className="card-item">
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div>
          <h3 className="font-poppins font-bold text-lg">{item.name}</h3>
          <p className="text-muted-foreground font-roboto text-sm">{item.category}</p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreVertical className="h-4 w-4" />
              <span className="sr-only">Actions</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={handleEdit}>
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleAddToShoppingList}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to shopping list
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={handleDelete}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-3">
          <div className="font-montserrat">
            <span className="text-lg font-bold">{item.quantity}</span>
            <span className="text-sm ml-1">{item.unit}</span>
          </div>
          <StatusBadge status={item.status} />
        </div>
        
        <div className="space-y-2 font-roboto text-sm">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span>Purchased {formatDistanceToNow(parseISO(item.purchaseDate))} ago</span>
          </div>
          
          {item.expirationDate && (
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <ExpirationBadge date={item.expirationDate} />
            </div>
          )}
        </div>
      </CardContent>
      {item.notes && (
        <CardFooter className="text-sm text-muted-foreground border-t pt-3">
          {item.notes}
        </CardFooter>
      )}
    </Card>
  );
};

export default PantryItemCard;


export interface PantryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  expirationDate: string | null;
  purchaseDate: string;
  status: 'open' | 'closed' | 'half-finished' | 'finished';
  notes?: string;
  lastPurchaseReminder?: string | null;
}

export interface ShoppingListItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  isPurchased: boolean;
  notes?: string;
  pantryItemId?: string;
}

export type PantryCategory = 
  | 'dairy' 
  | 'produce' 
  | 'meat' 
  | 'frozen' 
  | 'canned' 
  | 'dry' 
  | 'beverages' 
  | 'spices' 
  | 'bakery' 
  | 'snacks'
  | 'other';

export type UnitType = 
  | 'kg' 
  | 'g' 
  | 'l' 
  | 'ml' 
  | 'oz' 
  | 'lb' 
  | 'pcs' 
  | 'pack' 
  | 'box' 
  | 'can' 
  | 'bottle' 
  | 'jar';

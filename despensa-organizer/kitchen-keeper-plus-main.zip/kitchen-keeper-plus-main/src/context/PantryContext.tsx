
import React, { createContext, useContext, useEffect, useState } from 'react';
import { toast } from "sonner";
import { PantryItem, ShoppingListItem } from '../types/pantry';
import { addDays, formatDistanceToNow, isBefore, parseISO } from 'date-fns';

interface PantryContextType {
  pantryItems: PantryItem[];
  shoppingList: ShoppingListItem[];
  addPantryItem: (item: Omit<PantryItem, 'id'>) => void;
  updatePantryItem: (id: string, data: Partial<PantryItem>) => void;
  deletePantryItem: (id: string) => void;
  addToShoppingList: (item: Omit<ShoppingListItem, 'id'>) => void;
  updateShoppingListItem: (id: string, data: Partial<ShoppingListItem>) => void;
  removeFromShoppingList: (id: string) => void;
  checkExpiringSoon: () => void;
  checkLastPurchaseReminder: () => void;
  transferToShoppingList: (pantryItemId: string, quantity?: number) => void;
  markAsPurchased: (shoppingItemId: string) => void;
}

const PantryContext = createContext<PantryContextType | undefined>(undefined);

export const PantryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [pantryItems, setPantryItems] = useState<PantryItem[]>(() => {
    const saved = localStorage.getItem('pantryItems');
    return saved ? JSON.parse(saved) : [];
  });

  const [shoppingList, setShoppingList] = useState<ShoppingListItem[]>(() => {
    const saved = localStorage.getItem('shoppingList');
    return saved ? JSON.parse(saved) : [];
  });

  // Save to localStorage whenever our state changes
  useEffect(() => {
    localStorage.setItem('pantryItems', JSON.stringify(pantryItems));
  }, [pantryItems]);

  useEffect(() => {
    localStorage.setItem('shoppingList', JSON.stringify(shoppingList));
  }, [shoppingList]);

  // Check for expiring items on load
  useEffect(() => {
    checkExpiringSoon();
    checkLastPurchaseReminder();
    
    // Set up interval for daily checks
    const dailyCheck = setInterval(() => {
      checkExpiringSoon();
      checkLastPurchaseReminder();
    }, 86400000); // 24 hours
    
    return () => clearInterval(dailyCheck);
  }, [pantryItems]);

  const addPantryItem = (item: Omit<PantryItem, 'id'>) => {
    const newItem: PantryItem = {
      ...item,
      id: crypto.randomUUID(),
    };
    setPantryItems(prev => [...prev, newItem]);
    toast.success("Item added to pantry");
  };

  const updatePantryItem = (id: string, data: Partial<PantryItem>) => {
    setPantryItems(prev => 
      prev.map(item => 
        item.id === id ? { ...item, ...data } : item
      )
    );
    toast.success("Item updated");
  };

  const deletePantryItem = (id: string) => {
    setPantryItems(prev => prev.filter(item => item.id !== id));
    toast.info("Item removed from pantry");
  };

  const addToShoppingList = (item: Omit<ShoppingListItem, 'id'>) => {
    const newItem: ShoppingListItem = {
      ...item,
      id: crypto.randomUUID(),
    };
    setShoppingList(prev => [...prev, newItem]);
    toast.success("Item added to shopping list");
  };

  const updateShoppingListItem = (id: string, data: Partial<ShoppingListItem>) => {
    setShoppingList(prev => 
      prev.map(item => 
        item.id === id ? { ...item, ...data } : item
      )
    );
    toast.success("Shopping list item updated");
  };

  const removeFromShoppingList = (id: string) => {
    setShoppingList(prev => prev.filter(item => item.id !== id));
    toast.info("Item removed from shopping list");
  };

  const checkExpiringSoon = () => {
    const today = new Date();
    
    pantryItems.forEach(item => {
      if (item.expirationDate) {
        const expDate = parseISO(item.expirationDate);
        const threeDaysFromNow = addDays(today, 3);
        
        if (isBefore(expDate, threeDaysFromNow) && !isBefore(expDate, today)) {
          toast.warning(
            `"${item.name}" will expire in ${formatDistanceToNow(expDate)}`, 
            { 
              duration: 10000,
              action: {
                label: "Add to Shopping",
                onClick: () => transferToShoppingList(item.id),
              },
            }
          );
        }
        else if (isBefore(expDate, today)) {
          toast.error(
            `"${item.name}" expired ${formatDistanceToNow(expDate)} ago`, 
            { 
              duration: 10000,
            }
          );
        }
      }
    });
  };

  const checkLastPurchaseReminder = () => {
    const today = new Date();
    
    pantryItems.forEach(item => {
      if (item.status === 'finished' || item.quantity <= 0) {
        const purchaseDate = parseISO(item.purchaseDate);
        const thirtyDaysAgo = addDays(today, -30);
        
        if (isBefore(purchaseDate, thirtyDaysAgo) && !item.lastPurchaseReminder) {
          toast.info(
            `Your last purchase of "${item.name}" was ${formatDistanceToNow(purchaseDate)} ago. Add it to your shopping list?`,
            {
              duration: 15000,
              action: {
                label: "Add to List",
                onClick: () => transferToShoppingList(item.id),
              },
              onDismiss: () => {
                updatePantryItem(item.id, { 
                  lastPurchaseReminder: new Date().toISOString() 
                });
              }
            }
          );
        }
      }
    });
  };

  const transferToShoppingList = (pantryItemId: string, quantity?: number) => {
    const pantryItem = pantryItems.find(item => item.id === pantryItemId);
    
    if (pantryItem) {
      addToShoppingList({
        name: pantryItem.name,
        quantity: quantity || pantryItem.quantity,
        unit: pantryItem.unit,
        isPurchased: false,
        notes: `Last purchased: ${formatDistanceToNow(parseISO(pantryItem.purchaseDate))} ago`,
        pantryItemId: pantryItem.id
      });
    }
  };

  const markAsPurchased = (shoppingItemId: string) => {
    const item = shoppingList.find(i => i.id === shoppingItemId);
    if (!item) return;
    
    // If it's related to a pantry item, update the pantry item
    if (item.pantryItemId) {
      const pantryItem = pantryItems.find(p => p.id === item.pantryItemId);
      if (pantryItem) {
        updatePantryItem(pantryItem.id, {
          quantity: item.quantity,
          status: 'closed',
          purchaseDate: new Date().toISOString(),
          lastPurchaseReminder: null
        });
      }
    }
    
    // Mark as purchased and eventually remove from shopping list
    updateShoppingListItem(shoppingItemId, { isPurchased: true });
    
    // Remove from shopping list with a delay to allow the user to see it was purchased
    setTimeout(() => {
      removeFromShoppingList(shoppingItemId);
    }, 2000);
  };

  return (
    <PantryContext.Provider value={{
      pantryItems,
      shoppingList,
      addPantryItem,
      updatePantryItem,
      deletePantryItem,
      addToShoppingList,
      updateShoppingListItem,
      removeFromShoppingList,
      checkExpiringSoon,
      checkLastPurchaseReminder,
      transferToShoppingList,
      markAsPurchased
    }}>
      {children}
    </PantryContext.Provider>
  );
};

export const usePantry = () => {
  const context = useContext(PantryContext);
  if (!context) {
    throw new Error('usePantry must be used within a PantryProvider');
  }
  return context;
};
